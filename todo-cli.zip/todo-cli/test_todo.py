import pytest

import todo


def test_add_task():
    tasks = todo.add_task([], "buy milk")
    assert tasks == [{"text": "buy milk", "done": False}]


def test_complete_task():
    tasks = todo.add_task([], "buy milk")
    todo.complete_task(tasks, 1)
    assert tasks[0]["done"] is True


def test_remove_task():
    tasks = todo.add_task(todo.add_task([], "a"), "b")
    todo.remove_task(tasks, 1)
    assert [t["text"] for t in tasks] == ["b"]


def test_bad_number_raises():
    with pytest.raises(IndexError):
        todo.complete_task([], 1)


def test_save_and_load(tmp_path):
    path = tmp_path / "tasks.json"
    todo.save_tasks([{"text": "x", "done": False}], path)
    assert todo.load_tasks(path) == [{"text": "x", "done": False}]


def test_format_empty():
    assert "No tasks yet" in todo.format_tasks([])
